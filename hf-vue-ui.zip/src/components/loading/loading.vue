<template>
  <transition :name="cfg.prefix + '-loading-fade'" @after-leave="handleAfterLeave">
    <div
      v-show="visible"
      :style="{ backgroundColor: background || '' }"
      :class="[(cfg.prefix + '-loading-mask'), customClass, { 'is-fullscreen': fullscreen }]"
    >
      <div :class="[cfg.prefix + '-loading-spinner', type ? (cfg.prefix + '-loading-type-' + type) : '']">
        <svg v-if="!spinner" class="circular" viewBox="25 25 50 50">
          <circle class="path" cx="50" cy="50" r="20" fill="none" />
        </svg>
        <i v-else :class="spinner"></i>
        <p v-if="text" :class="cfg.prefix + '-loading-text'">
          {{ text }}
        </p>
      </div>
    </div>
  </transition>
</template>

<script>
export default {
  data() {
    return {
      text: null,
      spinner: null,
      background: null,
      fullscreen: true,
      visible: false,
      customClass: '',
      type: null
    };
  },

  methods: {
    handleAfterLeave() {
      this.$emit('after-leave');
    },
    setText(text) {
      this.text = text;
    }
  }
};
</script>
