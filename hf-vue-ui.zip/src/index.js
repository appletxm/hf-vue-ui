import './theme/index.scss'
import componentsCollection from './components-collection'

export default componentsCollection
