module.exports = {
  publicPath: '',
  distPath: './dist/lib',
  sourcePath: './src',
  prefix: 'hf-ui',
  componentPrefix: 'HfUi',
  userDefineTheme: {
    src: './tmp/themes',
    out: './tmp/themes-out'
  }
}
